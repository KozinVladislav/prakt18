<?php
include_once "../engine/connection.php";
include_once "../engine/function.php";
$types = array("image/jpg" , "image/png" , "image/jpeg" , "image/bmp");
$login = $_POST['login'];
if(isset($_FILES['avatar']) and $_FILES['avatar']['size'] > 0 and in_array($_FILES['avatar']['type'] , $types))
{
	$path = "../images/";
	$filename = rand(1000,10000) . $_FILES['avatar']['name'];
	$fullname = $path . $filename;
	$tmp_name = $_FILES['avatar']['tmp_name'];
	move_uploaded_file($tmp_name , $fullname);
	$connect->query("UPDATE `user` SET `avatar` = '$fullname' WHERE `login` = '$login'");
}
$query = $connect->query(" SELECT * FROM `user` WHERE `login` = '$login';");
$row = $query->fetch_assoc();

$mas = array();
$mas[1] = $row['name'];
$mas[2] = $row['surname'];
$mas[3] = $row['login'];
$mas[4] = $row['email'];
$mas[5] = $row['password'];
$mas[6] = $row['repeatPassword'];

$sub_checked = [

			'sub1' => ($row['sub1'] == '1') ? 'checked' : '',
			'sub2' => ($row['sub2'] == '1') ? 'checked' : '',
			'sub3' => ($row['sub3'] == '1') ? 'checked' : ''

		];

if (isset($_POST['subm']))
{
	if (count($_POST))
	{
		$sub = [

			'sub1' => 0,
			'sub2' => 0,
			'sub3' => 0

		];

		if (is_array($_POST['sub']))
			foreach ($_POST['sub'] as $s)
				$sub[$s] = 1;
		
		$pas = $_POST['password'];
		if ($pas === ($_POST['repeatPassword']))
		{
			$connect->query("UPDATE user SET name = '" . $_POST['name'] . "',
									surname 		= '" . $_POST['surname'] . "',
									email 			= '" . $_POST['email'] . "',
									password 		= '" . $_POST['password'] . "',
									repeatPassword 	= '" . $_POST['password'] . "',
									sub1 			= '" . $sub['sub1'] . "',
									sub2 			= '" . $sub['sub2'] . "',
									sub3 			= '" . $sub['sub3'] . "'	
									WHERE login = '" . $login . "' ");
			echo "Изменения приняты";
		} else die('поля Пароль и Повтор пароля не совпадают');
	}
}

$connect->close();