<?php
function test($value, $name, $pattern)
{
	if (!empty($_POST["$value"]))
	{	
		$var = $_POST["$value"];
		if (!preg_match($pattern, $var)) {
			die('Неккоректный ввод: ' . $name);
		}
	} else {
			die('Пустое поле: ' . $name);
		}
	
	return $var;
}

function testSub($sub)
{
	foreach ($_POST['sub'] as $key => $value) {
		if ($value === $sub) {
			return true;
		}
	}
	return false;
}
